<?php

	$len = 5;
	$wid = 8;

	echo "Area of the Rectangle: ".($len*$wid)."<br>";
	echo "Parameter of the Rectangle: ".(2*($len+$wid));

?>