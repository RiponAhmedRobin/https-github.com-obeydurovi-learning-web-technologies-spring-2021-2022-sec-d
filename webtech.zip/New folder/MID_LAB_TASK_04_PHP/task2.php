<?php

	$amount = 170;

	echo "VAT over the amount: ".(0.15*$amount)."tk only";

?>